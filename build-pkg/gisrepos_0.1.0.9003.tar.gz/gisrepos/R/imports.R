#' @importFrom utils browseURL globalVariables install.packages
#'     installed.packages update.packages
#' @importFrom rmarkdown render
#' @importFrom readODS read_ods
#' 
NULL

# Prevent NOTE by R CMD check
globalVariables(".gisrepos")
